rootProject.name = "DrMunnaAssistAI"
include(":app")
